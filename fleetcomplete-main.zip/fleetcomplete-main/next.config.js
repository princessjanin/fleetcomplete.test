/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['www.fleetcomplete.com.au'],
      },
}

module.exports = nextConfig
