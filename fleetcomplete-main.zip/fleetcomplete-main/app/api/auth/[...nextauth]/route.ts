
import { myAdminApi } from "@/lib/geolabAdmin";
import { CloudCog } from "lucide-react";
import { NextAuthOptions } from "next-auth";
import { AdapterUser } from "next-auth/adapters";
import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials";


interface UserProps extends AdapterUser {
    database: string;
    userName: string;
    sessionId: string;
}

export const authOptions: NextAuthOptions = {
    session:{
        strategy: "jwt",
        maxAge: 1200,
    },
    providers:[
        CredentialsProvider({
            name: "Email Address", 
            credentials: {
                username: { label: "Email Address", type: "text", placeholder: "Email Address" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials, req) {
                // Add logic here to look up the user from the credentials supplied
                const { query } = req

                const authentication = {
                    credentials: {
                        userName: credentials?.username,
                        password: credentials?.password,
                        database: query?.database
                    },
                    path: 'my.geotab.com'
                }

                const GeotabApi = require('mg-api-js');
                const api = new GeotabApi(authentication);
                
                let response = await api.authenticate().then( (data: any) => {
                    return data
                }).catch((err: any) => {
                    console.log("Error",err)
                    return {}
                });

                // const loginParams = {
                //     username: credentials?.username,
                //     password: credentials?.password,
                //     database: query?.database
                // }

                // var apiMethod = {
                //     "id": -1,
                //     "method": "Authenticate",
                //     "params": loginParams
                // };

                // let serverUrl = "https://myadminapi.geotab.com/v2/MyAdminApi.ashx";
                // let uri = encodeURIComponent(JSON.stringify(apiMethod))
                // const response = await fetch(`${serverUrl}`, {
                //     cache: 'no-store',
                //     method: "POST",
                //     headers:{
                //         "Content-Type": "application/x-www-form-urlencoded",
                //     },
                //     body: JSON.stringify(`JSON-RPC=${uri}`),
                // }); 


                
                let user = await response.credentials
                
                if(user){
                    return user;
                }else{
                    return null
                }
                

                
            }
        }),
    ],
    secret: process.env.NEXTAUTH_SECRET,
    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            return true
          },
          async redirect({ url, baseUrl }) {
            return url
          },
          async session({ session, token }) {
            session.user.database = token.database
            session.user.userName = token.userName
            session.user.sessionId = token.sessionId

            return session
          },
          async jwt({ token, user, account, profile }) {
            if(account){
                token.database = (user as UserProps).database;
                token.userName = (user as UserProps).userName;
                token.sessionId = (user as UserProps).sessionId;
            }
            return token
          }
    },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST};