import { CSSTeam } from '@/components/css/css-team'

const page = () => {
  return (
    <>
        <CSSTeam />
    </>
  )
}

export default page
