import NextAuth, { DefaultSession } from "next-auth"
import { JWT } from "next-auth/jwt"

declare module "next-auth/jwt" {
  /** Returned by the `jwt` callback and `getToken`, when using JWT sessions */
  interface JWT {
    /** OpenID ID Token */
    database: string;
    userName: string;
    sessionId: string;
  }
}

declare module "next-auth" {
  interface Session {
    user: {
      database: string;
      userName: string;
      sessionId: string;
    } & DefaultSession["user"]
  }
}